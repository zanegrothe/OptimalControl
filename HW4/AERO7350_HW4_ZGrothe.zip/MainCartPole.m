% Zane Grothe
% AERO 7350
% HW 4
% 11/10/23

clear all
close all
clc

% This script (accompanied with function file TPBVP_2ndOrder.m) finds the
% minimum energy dynamics for a cart-pole swing-up and balance for a given
% amount of time.
% Part 1 derives the generalized necessary conditions for optimality.
% Part 2 solves the 2pt BVP for the specified boundary conditions.
% This file creates 3 function files and returns 3 figures for analytical
% comparison.


%% Part 1

% Constants
m1 = 1;   % kg
m2 = 0.3; % kg
g = 9.81; % m/s^2
l = 0.5;  % meters

NofEq = 4; % establish size of our problem
syms t x th xd thd u

% Create states and costates vectors
xbar = [x;th;xd;thd]; % states
lambar = cell(NofEq,1);
for i = 1:NofEq
    lambar{i} = sprintf('lam%d',i);
end
lambar = lambar(:);
lambar = sym(lambar,'real'); % costates

L = 1/2*u^2; % define the Lagrangian

% Equations of motion
xdd = (m2*l*thd^2*sin(th) + m2*g*cos(th)*sin(th) + u) ...
                            / (m1 + m2*(1-cos(th)^2));
thdd = -(m2*l*thd^2*cos(th)*sin(th) + (m1+m2)*g*sin(th) + u*cos(th)) ...
                                       / (m1*l + m2*l*(1-cos(th)^2));
% State dynamics
xbard = [xd;thd;xdd;thdd];

%% Hamiltonian
H = L + lambar.'*xbard;

%% Costate Dynamics
lambard = -jacobian(H,xbar).';

%% Optimal Control
u0 = solve(diff(H,u),u);

y = [xbard;lambard];
y = subs(y,u,u0);
z = [xbar,lambar];

H0 = subs(H,u,u0);

% Create files for calculating these values to be called later
fc = matlabFunction(y,'file','CartPoleEOM.m','vars',{t,z},'outputs',{'zdot'});
dc = matlabFunction(u0,'file','Find_u0.m','vars',{z},'outputs',{'u0'});
ec = matlabFunction(H0,'file','Find_H0.m','vars',{z},'outputs',{'H0'});

%% Part 2

% Boundary Conditions
x0 = zeros(4,1); % start hanging at rest
xf = zeros(4,1); % finish balancing at rest
xf(2) = pi;

tf = 1; % time duration for minimum energy trajectory
tspan = [0,tf];

options = odeset('RelTol',1e-8,'AbsTol',1e-8);
options_fsolve = optimoptions('fsolve','Display','iter',...
    'MaxFunEvals',1000,'MaxIter',1000,'TolFun',1e-10,'Tolx',1e-10);
% use fsolve to iterate for a solution to the costate values
norm_fval = 1;
while norm_fval > 1e-4
    lambar0 = rand(4,1); % initial random guess
    [lam_sol,fval,exitflag,output] = fsolve(@TPBVP_2ndOrder,lambar0,options_fsolve,x0,xf,tspan,options);
    norm_fval = norm(fval); % compare the norms of the vectors
end

%% Plots

% Establish the final solution vector and propogate optimal trajectory
z0 = [x0;lam_sol];
[t_final,z_final] = ode45(@CartPoleEOM,tspan,z0,options);
Nd = length(t_final);
u0 = zeros(1,Nd);
H0 = u0;

% Calculate control and Hamiltonian for established final solution
for i = 1:Nd
    z_current = z_final(i,:).';
    u0(i) = Find_u0(z_current);
    H0(i) = Find_H0(z_current);
end

% Extract states and costates
x = z_final(:,1);
th = z_final(:,2);
xd = z_final(:,3);
thd = z_final(:,4);
lam1 = z_final(:,5);
lam2 = z_final(:,6);
lam3 = z_final(:,7);
lam4 = z_final(:,8);

figure(1) % states

subplot(2,2,1);
plot(t_final,x)
title('Cart Position')
ylabel('x (m)')

subplot(2,2,2);
plot(t_final,th)
title('Pendulum Angle')
ylabel('theta (rad)')

subplot(2,2,3);
plot(t_final,xd)
title('Cart Velocity')
ylabel('xdot (m/s)')

subplot(2,2,4);
plot(t_final,thd)
title('Pendulum Angular Velocity')
ylabel('theta dot (rad/s)')

figure(2) % control and Hamiltonian

subplot(2,1,1);
plot(t_final,u0)
title('Control')
ylabel('u (Newtons)')

subplot(2,1,2);
plot(t_final,H0)
title('Hamiltonian')

figure(3) % costates

subplot(2,2,1);
plot(t_final,lam1)
title('Costate 1')

subplot(2,2,2);
plot(t_final,lam2)
title('Costate 2')

subplot(2,2,3);
plot(t_final,lam3)
title('Costate 3')

subplot(2,2,4);
plot(t_final,lam4)
title('Costate 4')
